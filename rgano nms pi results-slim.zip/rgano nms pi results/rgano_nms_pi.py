#!/usr/bin/env python3
"""
Rgano × No Man's Sky Pi Dataset — Full Repo Scanner
=====================================================
Untrained edge detection across ALL procedural items in the zencq/Pi repo.

Core formula: edge_score(x) = 1 - consensus(x, neighbors(x))

Usage:
    python rgano_nms_pi.py --repo /path/to/Pi --output ./rgano_results

The script auto-discovers every category/family/tier in the repo and runs
5 edge detection strategies on each. Results are written as JSON per-family
plus a master summary.

Requires: pandas, pyarrow, numpy
    pip install pandas pyarrow numpy

Repo: https://github.com/zencq/Pi
"""

import argparse
import json
import os
import re
import sys
import time
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd


# ═══════════════════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════════════════

@dataclass
class RganoConfig:
    """Tunable parameters for the edge detection strategies."""
    # Strategy 1: Stat-space neighborhood
    stat_n_anchors: int = 500       # anchor points for proxy neighborhood
    stat_k_neighbors: int = 20      # k-nearest anchors for consensus

    # Strategy 4: Cross-tier consistency
    cross_tier_min_tiers: int = 3   # minimum tiers present to score a seed

    # General
    top_n_per_family: int = 25      # top edges to export per tier
    rng_seed: int = 42              # reproducibility


# ═══════════════════════════════════════════════════════════════════
#  REPO DISCOVERY
# ═══════════════════════════════════════════════════════════════════

@dataclass
class ItemFile:
    """A single parquet file in the repo."""
    category: str       # e.g. "Weapon", "Suit"
    family: str         # e.g. "UP_BOLT", "UA_HYP"
    tier: str           # e.g. "1", "2", "X", "single"
    path: Path

@dataclass
class ItemFamily:
    """A group of tiers for one item type."""
    category: str
    family: str
    files: dict = field(default_factory=dict)  # tier -> ItemFile

    @property
    def tier_count(self) -> int:
        return len(self.files)

    @property
    def tier_labels(self) -> list:
        return sorted(self.files.keys(), key=_tier_sort_key)


def _tier_sort_key(t: str) -> tuple:
    """Sort tiers: 0,1,2,3,4,X,single."""
    if t == "single":
        return (2, 0)
    if t == "X":
        return (1, 99)
    try:
        return (0, int(t))
    except ValueError:
        return (1, ord(t[0]))


def discover_repo(repo_path: Path) -> dict:
    """
    Walk the Pi repo and discover all parquet files.
    Returns: {category: {family: ItemFamily}}
    """
    catalog = defaultdict(dict)
    total = 0

    for folder in sorted(repo_path.iterdir()):
        if not folder.is_dir() or folder.name.startswith('.'):
            continue

        category = folder.name

        for f in sorted(folder.iterdir()):
            if f.suffix != '.parquet':
                continue

            stem = f.stem
            # Parse: PREFIX + TIER_SUFFIX (digit or X) or standalone
            m = re.match(r'^(.+?)(\d+|X)$', stem)
            if m:
                family_name, tier = m.group(1), m.group(2)
            else:
                family_name, tier = stem, "single"

            if family_name not in catalog[category]:
                catalog[category][family_name] = ItemFamily(
                    category=category, family=family_name
                )

            item_file = ItemFile(
                category=category,
                family=family_name,
                tier=tier,
                path=f,
            )
            catalog[category][family_name].files[tier] = item_file
            total += 1

    print(f"Discovered {total} parquet files across "
          f"{sum(len(fams) for fams in catalog.values())} families "
          f"in {len(catalog)} categories")

    return dict(catalog)


# ═══════════════════════════════════════════════════════════════════
#  DATA LOADING
# ═══════════════════════════════════════════════════════════════════

def get_stat_columns(df: pd.DataFrame) -> list:
    """Extract numeric stat columns (not Seed, Perfection, or Name)."""
    skip_prefixes = ('Seed', 'Perfection', 'Name ')
    return [
        c for c in df.columns
        if not any(c.startswith(p) for p in skip_prefixes)
        and df[c].dtype in ('float64', 'float32', 'int64', 'int32')
    ]


def load_tier(item_file: ItemFile) -> pd.DataFrame:
    """Load a single parquet file and tag it."""
    df = pd.read_parquet(item_file.path)
    df['_tier'] = item_file.tier
    df['_category'] = item_file.category
    df['_family'] = item_file.family
    return df


# ═══════════════════════════════════════════════════════════════════
#  RGANO EDGE DETECTION STRATEGIES
# ═══════════════════════════════════════════════════════════════════

def strategy_stat_space(df: pd.DataFrame, cfg: RganoConfig) -> np.ndarray:
    """
    Strategy 1: Stat-Space Neighborhood Edges
    neighbors(x) = items with closest stat vectors
    consensus(x) = inverse distance to k-nearest anchor points
    edge_score = 1 - consensus
    """
    stat_cols = get_stat_columns(df)
    if not stat_cols:
        return np.zeros(len(df))

    normed = df[stat_cols].copy()
    for c in stat_cols:
        mn, mx = normed[c].min(), normed[c].max()
        if mx > mn:
            normed[c] = (normed[c] - mn) / (mx - mn)
        else:
            normed[c] = 0.5
    normed = normed.fillna(0.5)

    vals = normed.values
    n = len(vals)
    rng = np.random.RandomState(cfg.rng_seed)
    n_anchors = min(cfg.stat_n_anchors, n)
    anchors_idx = rng.choice(n, n_anchors, replace=False)
    anchor_vals = vals[anchors_idx]

    k = min(cfg.stat_k_neighbors, n_anchors)
    scores = np.zeros(n)
    for i in range(n):
        dists = np.sqrt(np.sum((anchor_vals - vals[i]) ** 2, axis=1))
        k_nearest = np.sort(dists)[:k]
        consensus = 1.0 / (1.0 + np.mean(k_nearest))
        scores[i] = 1.0 - consensus

    return scores


def strategy_name_cluster(df: pd.DataFrame) -> np.ndarray:
    """
    Strategy 2: Name-Cluster Deviation Edges
    neighbors(x) = items with the same procedural name
    consensus(x) = how close stats are to the name-group mean
    """
    stat_cols = get_stat_columns(df)
    if not stat_cols or 'Name (en)' not in df.columns:
        return np.zeros(len(df))

    scores = np.zeros(len(df))

    for _, group in df.groupby('Name (en)'):
        if len(group) < 2:
            continue
        group_stats = group[stat_cols].fillna(group[stat_cols].median())
        group_mean = group_stats.mean()
        group_std = group_stats.std().replace(0, 1)

        z_scores = ((group_stats - group_mean) / group_std).abs().mean(axis=1)
        max_z = z_scores.max()
        edge = z_scores / max_z if max_z > 0 else z_scores
        scores[group.index] = edge.values

    return scores


def strategy_perfection_paradox(df: pd.DataFrame) -> np.ndarray:
    """
    Strategy 3: Perfection Paradox Edges
    Detects items where PerfectionSingle and PerfectionComparable disagree —
    the game's own scoring system can't make up its mind.
    """
    if 'PerfectionSingle' not in df.columns or 'PerfectionComparable' not in df.columns:
        return np.zeros(len(df))

    ps = df['PerfectionSingle'].fillna(0)
    pc = df['PerfectionComparable'].fillna(0)

    def norm(s):
        mn, mx = s.min(), s.max()
        return (s - mn) / (mx - mn) if mx > mn else s * 0 + 0.5

    return (norm(ps) - norm(pc)).abs().values


def strategy_nan_pattern(df: pd.DataFrame) -> np.ndarray:
    """
    Strategy 4: NaN Pattern Edges
    When a family has multiple stat columns and some seeds get NaN on
    certain stats, the procedural generator made a CHOICE. Seeds that
    deviate from the majority pattern (or sit at extremes of their
    branch) are edges.
    """
    stat_cols = get_stat_columns(df)
    if len(stat_cols) < 2:
        return np.zeros(len(df))

    # Build NaN signature per row
    nan_mask = df[stat_cols].isna()
    nan_signatures = nan_mask.apply(lambda r: tuple(r), axis=1)
    sig_counts = nan_signatures.value_counts()

    if len(sig_counts) <= 1:
        # No NaN variation — no fork
        return np.zeros(len(df))

    # Majority signature
    majority_sig = sig_counts.index[0]
    majority_frac = sig_counts.iloc[0] / len(df)

    scores = np.zeros(len(df))

    for sig, group_idx in nan_signatures.groupby(nan_signatures):
        mask = group_idx.index
        if sig == majority_sig and majority_frac > 0.9:
            # Majority group: edge based on stat extremes
            for c in stat_cols:
                col = df.loc[mask, c].dropna()
                if len(col) > 1 and col.std() > 0:
                    med = col.median()
                    mad = (col - med).abs().median()
                    if mad > 0:
                        edge_vals = (col - med).abs() / mad
                        edge_vals = edge_vals / edge_vals.max()
                        scores[col.index] = np.maximum(
                            scores[col.index], edge_vals.values
                        )
        else:
            # Minority NaN pattern — these seeds ARE edges by nature
            # Scale by how rare this pattern is
            rarity = 1.0 - (len(mask) / len(df))
            for c in stat_cols:
                col = df.loc[mask, c].dropna()
                if len(col) > 1 and col.std() > 0:
                    med = col.median()
                    mad = (col - med).abs().median()
                    if mad > 0:
                        edge_vals = (col - med).abs() / mad
                        edge_vals = edge_vals / edge_vals.max()
                        scores[col.index] = np.maximum(
                            scores[col.index], edge_vals.values * rarity
                        )
                    else:
                        scores[mask] = np.maximum(scores[mask], rarity)
                else:
                    scores[mask] = np.maximum(scores[mask], rarity)

    # Bonus for seeds with unusual NaN patterns (fork detection)
    for sig, group_idx in nan_signatures.groupby(nan_signatures):
        mask = group_idx.index
        frac = len(mask) / len(df)
        # Near 50/50 splits are the most interesting forks
        fork_score = 1.0 - abs(frac - 0.5) * 2  # peaks at 50/50
        if fork_score > 0.5 and len(sig_counts) == 2:
            # Clean binary fork — boost items at extremes of their branch
            pass  # already handled above

    return scores


def strategy_cross_tier(
    family: ItemFamily,
    tier_dfs: dict,
    cfg: RganoConfig,
) -> dict:
    """
    Strategy 5: Cross-Tier Seed Consistency
    Same seed across tiers — does it stay edge-like or flip?
    Returns: {seed: {"variance": float, tier_label: percentile_rank, ...}}
    """
    seed_profiles = defaultdict(dict)

    for tier_label, df in tier_dfs.items():
        if 'PerfectionComparable' not in df.columns:
            continue
        pc = df.set_index('Seed')['PerfectionComparable']
        ranks = pc.rank(pct=True)
        for seed, rank in ranks.items():
            seed_profiles[seed][tier_label] = float(rank)

    results = {}
    for seed, profile in seed_profiles.items():
        if len(profile) >= cfg.cross_tier_min_tiers:
            vals = list(profile.values())
            results[int(seed)] = {
                "variance": float(np.std(vals)),
                "avg_rank": float(np.mean(vals)),
                **{f"t{k}": round(v, 5) for k, v in profile.items()},
            }

    return results


# ═══════════════════════════════════════════════════════════════════
#  MAIN ANALYSIS PIPELINE
# ═══════════════════════════════════════════════════════════════════

def analyze_family(
    family: ItemFamily,
    cfg: RganoConfig,
) -> dict:
    """
    Run all Rgano strategies on a single item family.
    Returns a dict of results ready for JSON serialization.
    """
    print(f"\n{'─'*60}")
    print(f"  {family.category}/{family.family} "
          f"({family.tier_count} tier{'s' if family.tier_count > 1 else ''})")
    print(f"{'─'*60}")

    tier_dfs = {}
    for tier_label in family.tier_labels:
        item_file = family.files[tier_label]
        df = load_tier(item_file)
        tier_dfs[tier_label] = df
        print(f"  Loaded tier {tier_label}: "
              f"{len(df)} items, "
              f"{len(get_stat_columns(df))} stats")

    # ── Per-tier strategies ──
    tier_results = {}
    for tier_label, df in tier_dfs.items():
        t0 = time.time()

        stat_cols = get_stat_columns(df)

        s1 = strategy_stat_space(df, cfg)
        s2 = strategy_name_cluster(df)
        s3 = strategy_perfection_paradox(df)
        s4 = strategy_nan_pattern(df)

        df['edge_stat_space'] = s1
        df['edge_name_cluster'] = s2
        df['edge_perfection_paradox'] = s3
        df['edge_nan_pattern'] = s4

        edge_cols = ['edge_stat_space', 'edge_name_cluster',
                     'edge_perfection_paradox', 'edge_nan_pattern']
        df['edge_composite'] = df[edge_cols].mean(axis=1)

        elapsed = time.time() - t0
        print(f"  Tier {tier_label}: composite range "
              f"[{df['edge_composite'].min():.4f}, "
              f"{df['edge_composite'].max():.4f}] ({elapsed:.1f}s)")

        # ── Collect tier summary ──
        top_edges = df.nlargest(cfg.top_n_per_family, 'edge_composite')
        top_edge_records = []
        for _, row in top_edges.iterrows():
            rec = {
                "seed": int(row['Seed']),
                "name": row.get('Name (en)', ''),
                "edge_composite": round(float(row['edge_composite']), 5),
                "edge_stat_space": round(float(row['edge_stat_space']), 5),
                "edge_name_cluster": round(float(row['edge_name_cluster']), 5),
                "edge_perfection_paradox": round(float(row['edge_perfection_paradox']), 5),
                "edge_nan_pattern": round(float(row['edge_nan_pattern']), 5),
                "perfection_single": round(float(row.get('PerfectionSingle', 0)), 5),
                "perfection_comparable": round(float(row.get('PerfectionComparable', 0)), 5),
            }
            # Include all stat values
            for c in stat_cols:
                val = row[c]
                rec[c] = round(float(val), 4) if pd.notna(val) else None
            top_edge_records.append(rec)

        # Name edge rankings
        name_rankings = []
        if 'Name (en)' in df.columns:
            name_agg = df.groupby('Name (en)')['edge_composite'].agg(
                ['mean', 'std', 'max', 'count']
            ).reset_index()
            name_agg = name_agg.sort_values('mean', ascending=False)
            for _, nr in name_agg.iterrows():
                name_rankings.append({
                    "name": nr['Name (en)'],
                    "edge_mean": round(float(nr['mean']), 5),
                    "edge_std": round(float(nr['std']), 5) if pd.notna(nr['std']) else 0,
                    "edge_max": round(float(nr['max']), 5),
                    "count": int(nr['count']),
                })

        # NaN fork analysis
        nan_fork = None
        if len(stat_cols) >= 2:
            nan_mask = df[stat_cols].isna()
            nan_sigs = nan_mask.apply(lambda r: tuple(r), axis=1)
            sig_counts = nan_sigs.value_counts()
            if len(sig_counts) > 1:
                fork_entries = []
                for sig, count in sig_counts.items():
                    null_cols = [stat_cols[j] for j, is_null in enumerate(sig) if is_null]
                    present_cols = [stat_cols[j] for j, is_null in enumerate(sig) if not is_null]
                    fork_entries.append({
                        "null_stats": null_cols,
                        "present_stats": present_cols,
                        "count": int(count),
                        "pct": round(count / len(df) * 100, 2),
                    })
                nan_fork = {
                    "num_branches": len(sig_counts),
                    "branches": fork_entries,
                }

        # Edge distribution histogram
        hist_vals, hist_edges = np.histogram(df['edge_composite'], bins=50)

        tier_results[tier_label] = {
            "tier": tier_label,
            "item_count": len(df),
            "stat_columns": stat_cols,
            "unique_names": int(df['Name (en)'].nunique()) if 'Name (en)' in df.columns else 0,
            "edge_mean": round(float(df['edge_composite'].mean()), 5),
            "edge_std": round(float(df['edge_composite'].std()), 5),
            "edge_min": round(float(df['edge_composite'].min()), 5),
            "edge_max": round(float(df['edge_composite'].max()), 5),
            "histogram": {
                "counts": hist_vals.tolist(),
                "bin_edges": [round(float(x), 5) for x in hist_edges],
            },
            "top_edges": top_edge_records,
            "name_rankings": name_rankings,
            "nan_fork": nan_fork,
        }

    # ── Cross-tier strategy ──
    cross_tier_data = None
    if family.tier_count >= 2:
        print(f"  Cross-tier analysis ({family.tier_count} tiers)...")
        cross_scores = strategy_cross_tier(family, tier_dfs, cfg)
        if cross_scores:
            sorted_by_var = sorted(
                cross_scores.items(), key=lambda x: x[1]["variance"], reverse=True
            )
            chameleons = [
                {"seed": s, **d} for s, d in sorted_by_var[:25]
            ]
            steady = [
                {"seed": s, **d} for s, d in sorted_by_var[-25:]
            ]
            cross_tier_data = {
                "total_seeds_scored": len(cross_scores),
                "chameleons": chameleons,
                "steady_eddies": steady,
            }

    return {
        "category": family.category,
        "family": family.family,
        "tier_count": family.tier_count,
        "tiers_available": family.tier_labels,
        "tier_results": tier_results,
        "cross_tier": cross_tier_data,
    }


def build_master_summary(all_results: list) -> dict:
    """
    Build a top-level summary across all families.
    Surfaces the most interesting finds in the entire dataset.
    """
    global_edges = []          # (composite, seed, name, category, family, tier)
    global_chameleons = []     # (variance, seed, category, family)
    family_summaries = []
    total_items = 0

    for result in all_results:
        cat = result["category"]
        fam = result["family"]

        for tier_label, tier_data in result["tier_results"].items():
            total_items += tier_data["item_count"]
            for edge in tier_data["top_edges"][:5]:
                global_edges.append({
                    "edge_composite": edge["edge_composite"],
                    "seed": edge["seed"],
                    "name": edge["name"],
                    "category": cat,
                    "family": fam,
                    "tier": tier_label,
                })

        if result["cross_tier"] and result["cross_tier"]["chameleons"]:
            for cham in result["cross_tier"]["chameleons"][:3]:
                global_chameleons.append({
                    "variance": cham["variance"],
                    "seed": cham["seed"],
                    "category": cat,
                    "family": fam,
                })

        # Family-level summary
        tier_data_list = list(result["tier_results"].values())
        family_summaries.append({
            "category": cat,
            "family": fam,
            "tiers": result["tier_count"],
            "total_items": sum(t["item_count"] for t in tier_data_list),
            "max_edge": max(t["edge_max"] for t in tier_data_list),
            "has_nan_fork": any(
                t["nan_fork"] is not None for t in tier_data_list
            ),
        })

    # Sort globals
    global_edges.sort(key=lambda x: x["edge_composite"], reverse=True)
    global_chameleons.sort(key=lambda x: x["variance"], reverse=True)
    family_summaries.sort(key=lambda x: x["max_edge"], reverse=True)

    # Families with NaN forks
    forked_families = [f for f in family_summaries if f["has_nan_fork"]]

    return {
        "total_items_analyzed": total_items,
        "total_families": len(all_results),
        "total_categories": len(set(r["category"] for r in all_results)),
        "strategies_used": [
            "stat_space", "name_cluster", "perfection_paradox",
            "nan_pattern", "cross_tier",
        ],
        "top_50_global_edges": global_edges[:50],
        "top_25_chameleon_seeds": global_chameleons[:25],
        "family_rankings": family_summaries,
        "families_with_nan_forks": forked_families,
    }


# ═══════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ═══════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Rgano edge detection on the NMS Pi dataset"
    )
    parser.add_argument(
        "--repo", type=str, required=True,
        help="Path to the cloned zencq/Pi repo"
    )
    parser.add_argument(
        "--output", type=str, default="./rgano_results",
        help="Output directory for JSON results"
    )
    parser.add_argument(
        "--category", type=str, default=None,
        help="Only process a specific category (e.g. 'Weapon', 'Suit')"
    )
    parser.add_argument(
        "--family", type=str, default=None,
        help="Only process a specific family (e.g. 'UP_BOLT')"
    )
    parser.add_argument(
        "--top-n", type=int, default=25,
        help="Number of top edges to export per tier (default: 25)"
    )
    args = parser.parse_args()

    repo_path = Path(args.repo)
    if not repo_path.exists():
        print(f"ERROR: Repo path does not exist: {repo_path}")
        sys.exit(1)

    output_path = Path(args.output)
    output_path.mkdir(parents=True, exist_ok=True)

    cfg = RganoConfig(top_n_per_family=args.top_n)

    # ── Discover ──
    print(f"\n{'═'*60}")
    print(f"  RGANO × NMS Pi — Full Repo Edge Detection")
    print(f"  Repo: {repo_path}")
    print(f"  Output: {output_path}")
    print(f"{'═'*60}\n")

    catalog = discover_repo(repo_path)

    # ── Filter if requested ──
    if args.category:
        if args.category not in catalog:
            print(f"ERROR: Category '{args.category}' not found. "
                  f"Available: {list(catalog.keys())}")
            sys.exit(1)
        catalog = {args.category: catalog[args.category]}

    if args.family:
        filtered = {}
        for cat, families in catalog.items():
            if args.family in families:
                filtered[cat] = {args.family: families[args.family]}
        if not filtered:
            all_fams = [f for fams in catalog.values() for f in fams]
            print(f"ERROR: Family '{args.family}' not found. "
                  f"Available: {all_fams[:10]}...")
            sys.exit(1)
        catalog = filtered

    # ── Analyze ──
    t_start = time.time()
    all_results = []

    for category, families in sorted(catalog.items()):
        print(f"\n{'▓'*60}")
        print(f"  CATEGORY: {category} ({len(families)} families)")
        print(f"{'▓'*60}")

        cat_output = output_path / category
        cat_output.mkdir(exist_ok=True)

        for family_name, family in sorted(families.items()):
            result = analyze_family(family, cfg)
            all_results.append(result)

            # Write per-family JSON
            family_file = cat_output / f"{family_name}.json"
            with open(family_file, 'w') as f:
                json.dump(result, f, indent=2)
            print(f"  → Wrote {family_file}")

    # ── Master summary ──
    print(f"\n\n{'═'*60}")
    print(f"  BUILDING MASTER SUMMARY")
    print(f"{'═'*60}")

    summary = build_master_summary(all_results)
    summary_file = output_path / "SUMMARY.json"
    with open(summary_file, 'w') as f:
        json.dump(summary, f, indent=2)

    elapsed = time.time() - t_start

    # ── Print highlights ──
    print(f"\n\n{'═'*60}")
    print(f"  RGANO ANALYSIS COMPLETE")
    print(f"{'═'*60}")
    print(f"  Total items analyzed: {summary['total_items_analyzed']:,}")
    print(f"  Total families:       {summary['total_families']}")
    print(f"  Total categories:     {summary['total_categories']}")
    print(f"  Elapsed time:         {elapsed:.1f}s")
    print(f"  Results directory:     {output_path}")
    print(f"  Master summary:        {summary_file}")

    print(f"\n  🔥 TOP 10 GLOBAL EDGES:")
    for i, e in enumerate(summary['top_50_global_edges'][:10], 1):
        print(f"    {i:>2}. [{e['category']}/{e['family']} T{e['tier']}] "
              f"Seed {e['seed']:>6} = {e['edge_composite']:.5f}  "
              f"\"{e['name']}\"")

    if summary['top_25_chameleon_seeds']:
        print(f"\n  🦎 TOP 5 CHAMELEON SEEDS:")
        for i, c in enumerate(summary['top_25_chameleon_seeds'][:5], 1):
            print(f"    {i:>2}. [{c['category']}/{c['family']}] "
                  f"Seed {c['seed']:>6}  variance={c['variance']:.5f}")

    if summary['families_with_nan_forks']:
        print(f"\n  🌀 FAMILIES WITH NaN FORKS ({len(summary['families_with_nan_forks'])}):")
        for f in summary['families_with_nan_forks'][:10]:
            print(f"    - {f['category']}/{f['family']} ({f['tiers']} tiers)")

    print(f"\n  Done. Explore results in {output_path}/")
    print(f"  Each category folder has per-family JSON files.")
    print(f"  SUMMARY.json has the global rankings and cross-family insights.")


if __name__ == "__main__":
    main()
